# Catatan Belanja & Hutang

Aplikasi web statis untuk mencatat belanja dan hutang. Tidak membutuhkan build command atau backend.

## Deploy ke Vercel

### Cara 1 — lewat dashboard Vercel
1. Ekstrak ZIP ini.
2. Unggah folder `catatan-belanja-vercel` ke repositori GitHub.
3. Di Vercel, pilih **Add New → Project**, lalu impor repositori tersebut.
4. Framework Preset: **Other**.
5. Build Command: kosongkan / **Override** lalu nonaktifkan.
6. Output Directory: `public`.
7. Klik **Deploy**.

### Cara 2 — Vercel CLI
Di komputer yang sudah terpasang Node.js dan Vercel CLI:
```bash
cd catatan-belanja-vercel
vercel
```
Ikuti instruksi CLI. Untuk deploy produksi:
```bash
vercel --prod
```

## Catatan penting
- Aplikasi menyimpan catatan di `localStorage` browser, jadi data tidak otomatis tersinkron antarperangkat.
- Data dapat hilang jika data situs/browser dihapus. Gunakan menu **Data → Ekspor cadangan** secara berkala.
- File ini tidak memiliki akun/login atau database server.
